
##### Testing the login function 

###### TODO

+ test1
+ test2
